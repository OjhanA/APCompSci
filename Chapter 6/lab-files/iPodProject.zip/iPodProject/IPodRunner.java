
public class IPodRunner
{
	public static void main (String[] args)
	{

	  // create an iPod object

	  // add your songs to the iPod

	  // print out the songs on the iPod

	  // ask the user to play a song, call the playSong() method of iPod



	}
}